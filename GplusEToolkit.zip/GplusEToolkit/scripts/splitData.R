ClinicalRegistration.with.header <- read.csv(paste(getwd(),"/GplusE/ClinicalRegistration-with-header.csv", sep=""), sep=";")
Diagnose.with.header <- read.csv(paste(getwd(),"/GplusE/Diagnose-with-header.csv", sep=""), sep=";")
#require("reshape2")
#ClinicalRegistration.with.header.unmelt <- dcast(ClinicalRegistration.with.header, InterbullNumber + DIM + ScoreDatetime + Period ~ Registration)
#Diagnose.with.header.unmelt <- dcast(Diagnose.with.header, InterbullNumber + DIM ~ Diagnose )
ClinicalRegistration.with.header.split <- split(ClinicalRegistration.with.header, ClinicalRegistration.with.header$Registration)
Diagnose.with.header.split <- split(Diagnose.with.header, Diagnose.with.header$Diagnose)
for ( name in names(ClinicalRegistration.with.header.split) )
{
  write.table(ClinicalRegistration.with.header.split[[name]], paste(paste(getwd(),"/GplusE/ClinicalRegistration",sep=""),name,"with-header.csv",sep="-"),quote = FALSE,row.names=FALSE,sep = ";")#,col.names=colnames(ClinicalRegistration.with.header.split[name]))
}
for ( name in names(Diagnose.with.header.split) )
{
  write.table(Diagnose.with.header.split[[name]], paste(paste(getwd(),"/GplusE/Diagnose",sep=""),name,"with-header.csv",sep="-"),quote = FALSE,row.names=FALSE,sep = ";")#,col.names= colnames(Diagnose.with.header.split[name]))
}